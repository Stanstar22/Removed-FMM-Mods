Halo Reach Magnum local cosmetic mod for Halo Online Eldewrito ms23 build.
Made by Bungie, ported by dany5639 using Shockfire's TagTool and Camden's commands.

Unzip into your game's main folder. It should look like:
Halo Online\mods\tagMods\reachMods\reachMagnum\reachMagnum.fm

Use FMM (FoundationMM by Clef) to install the mod.

Use that .bat to install the mod in case there's an issue with FMM.

Make sure you install this AFTER other mods.

It should be compatible with any mods.

3rd person animations may be wrong, but blame Bungie for that.

There's a few tweaks here and there to be done, so check once in a while for an update.

The zip contains tagtool and my tool, source on https://github.com/dany5639/HOTTCC . 
TTCC or HOTTCC reads the last tag of your game and converts the commands using that.